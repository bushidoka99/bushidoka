<h3 align="center">Hello there, I'm Umut 👋</h3>
<h5 align="center">
</h5>
<div align="center">
  <a href="https://discord.com/users/946115914854694993" title="Discord Account"><img src="https://lanyard-profile-readme.vercel.app/api/946115914854694993"></a>
</div>
<br>
<p align="center">
  Hi, I'm Umut, High School Student from Turkey
  <br>
  <br>
  💻 I love writing code and learn anythings about it
  <br>
  📚 I’m currently learning JavaScript
  <br>
  📫 How to reach me: <a href="mailto: bushidoka@protonmail.com">bushidoka@protonmail.com</a>
</p>

<hr>

<h2 align="center">Languages & Frameworks & Tools & Abilities</h2>

<p align="center">
  <code><img title="C#" height="25" src="/images/cSharp.svg"></code>
  <code><img title="Javascript" height="25" src="/images/javascript.svg"></code>
  <code><img title="Problem Solving" height="25" src="/images/problemSolving.png"></code>
  <code><img title="HTML5" height="25" src="/images/html5.svg"></code>
  <code><img title="CSS" height="25" src="/images/css.svg"></code>
  <code><img title="React" height="25" src="/images/react-original.svg"></code>
  <code><img title="Git" height="25" src="/images/git-original.svg"></code>
  <code><img title=".NetCore" height="25" src="/images/dotnetcore.svg"></code>
  <code><img title="Visual Studio Code" height="25" src="/images/vscode.png"></code>
  <code><img title="Microsoft Visual Studio" height="25" src="/images/visualstudio.png"></code>
  <code><img title="JQuery" height="25" src="/images/jquery-original.svg"></code>
  <code><img title="Java" height="25" src="/images/java-original.svg"></code>
  <code><img title="JSON" height="25" src="/images/json.svg"></code>
</p>

<hr>

<p align=center>
  <a href="https://github.com/anuraghazra/github-readme-stats" title="Go to Source">
    <img height=175 align="center" src="https://github-readme-stats.vercel.app/api?username=bushidoka99&show_icons=true&theme=gotham">
  </a>
  <a href="https://github.com/anuraghazra/github-readme-stats">
  <img height=175 align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=bushidoka99&hide=c%23,powershell,java&title_color=2aa889&text_color=99d1ce&icon_color=2bbc8a&bg_color=0c1014&langs_count=8&layout=compact" />
  </a>
</p>

<hr>
<br>
<h4 align="center"><a href=https://github.com/bushidoka99?tab=repositories" title="Show Repositories">🔎 Check my Repositories 🔍</a></h4>
